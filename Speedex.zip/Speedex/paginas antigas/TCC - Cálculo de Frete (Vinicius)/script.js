function calcular_frete() {
    valor = parseFloat(document.querySelector('input[name="frete-radio"]:checked').value);
    frete=(valor+7);

    document.getElementById("valorFrete").innerHTML = "R$" + frete.toFixed(2);
}
