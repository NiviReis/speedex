<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/style_login.css">
    <title>Spee>ex</title>
</head>

<body>

    <img src="outros/speedex.png" class="logo">
    <br>

    <section class="formularios">

        <!-------------------------------- LOGIN DE ENTREGADOR -------------------------------->

        <form class="form" method="POST" action="login/processa_login.php">
            <input type="hidden" name="operacao" value="login_entregador">
            <p class="form-title">Entregador</p>
            <div class="input-container">
                <input type="email" placeholder="E-mail" name="email" required>
                <span>
                </span>
            </div>
            <div class="input-container">
                <input type="password" placeholder="Senha" name="senha" required>
            </div>
            <button type="submit" class="submit">
                Entrar
            </button>

            <p class="signup-link">
                Não tem uma conta?
                <a href="login/cadastro_entregador.php">Cadastre-se</a>
            </p>
        </form>

        <!-------------------------------- LOGIN DE EMPRESA -------------------------------->

        <form class="form" method="POST" action="login/processa_login.php">
            <input type="hidden" name="operacao" value="login_empresa">
            <p class="form-title">Empresa</p>
            <div class="input-container">
                <input type="email" placeholder="E-mail" name="email" required>
                <span>
                </span>
            </div>
            <div class="input-container">
                <input type="password" placeholder="Senha" name="senha" required>
            </div>
            <button type="submit" class="submit">
                Entrar
            </button>

            <p class="signup-link">
                Não tem uma conta?
                <a href="login/cadastro_empresa.php">Cadastre-se</a>
            </p>
        </form>

        <!-------------------------------- LOGIN PESSOAL -------------------------------->

        <form class="form" method="POST" action="login/processa_login.php">
            <input type="hidden" name="operacao" value="login_pessoal">
            <p class="form-title">Pessoal</p>
            <div class="input-container">
                <input type="email" placeholder="E-mail" name="email" required>
                <span>
                </span>
            </div>
            <div class="input-container">
                <input type="password" placeholder="Senha" name="senha" required>
            </div>
            <button type="submit" class="submit">
                Entrar
            </button>

            <p class="signup-link">
                Não tem uma conta?
                <a href="login/cadastro_pessoal.php">Cadastre-se</a>
            </p>
        </form>
    </section>
</body>

</html>