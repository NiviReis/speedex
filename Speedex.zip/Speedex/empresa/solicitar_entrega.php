<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..\css\style_solicitar.css">
    <title>Solicitar Entrega</title>
</head>

<body>
    <header>
        <img src="..\outros\speedex.png" alt="Logo do Sistema de Pedidos" />

        <nav>
            <a href="#pedidos">Pedidos</a>
            <a href="#historico">Histórico</a>
            <a href="#entregadores">Entregadores</a>
        </nav>
    </header>

    <section class="pedidos">
        <div class="especificacoes">
            <h3>Especificações</h3>
            <form>
                <div class="input-container">
                    <div class="section">
                        <div class="endereco-bairro">
                            <label for="endereco">Endereço de Saída:</label>
                            <section class="sec2">
                                <input type="text" id="endereco" name="endereco" class="inptend" required>

                                <input type="text" id="endereco" name="endereco" class="inptnum" required>
                            </section>

                            <label for="bairro">Bairro Remetente:</label>
                            <input type="text" id="bairro" name="bairro" required>
                        </div>


                        <label for="objetivo">Objetivo Final:</label>
                        <input type="text" id="objetivo" name="objetivo" required>

                        <label for="dimensoes">Dimensões:</label>
                        <input type="text" id="dimensoes" name="dimensoes" required>

                        <label for="peso">Peso:</label>
                        <input type="text" id="peso" name="peso" required>
                    </div>

                    <div class="section">
                        <section class="bairro">
                            <label for="bairro">Bairro Destinátario:</label>
                            <input type="text" id="bairro" name="bairro" required>

                            <label for="cidade">Cidade:</label>
                            <input type="text" id="cidade" name="cidade" required>
                        </section>
                    </div>
                </div>

                <button type="submit">Fazer Pedido</button>
            </form>
        </div>
    </section>
    <footer>
        <?php
        include "../outros/rodape.inc"
        ?>
    </footer>
</body>

</html>