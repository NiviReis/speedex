<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spee>ex</title>

    <style>
        /*Cabecalho*/
        header {
            display: flex;
            justify-content: space-between;
            flex-direction: row;
            align-items: center;
        }

        /*logo*/
        img {
            max-width: 15%;
            height: auto;
            float: left;
            margin-right: 20px;
        }

        nav{
            font-weight: bold;
        }

        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
            /* Isso fará com que o conteúdo principal ocupe o espaço restante na página. */
        }

        /* Estilos da tabela */
        table {
            border-collapse: collapse;
            width: 100%;
            border-radius: 10px;
            overflow: hidden;
            /* Cor do overflow igual à cor da borda da tabela */
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
            width: 10%;
        }

        th {
            text-align: center;
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        /* Estilos para a coluna Situação */
        td.situacao {
            font-weight: bold;
            padding: 8px;
        }

        /*rodapé*/
        a {
            text-decoration: none;
            color: black;
        }

        a :hover {
            text-decoration: none;
            color: black;
        }
    </style>
</head>


<body>
    <header>
        <img src="..\outros\speedex.png" alt="Logo do Sistema de Pedidos" />

        <nav>
            <a href="#pedidos">Pedidos</a>
            <a href="#historico">Histórico</a>
            <a href="#entregadores">Entregadores</a>
        </nav>
    </header>

    <main>
        <?php
        //include "incs/validaEntregador.inc";
        include "../outros/conexao.inc";
        ?>
        <table>
            <thead>
                <tr>
                    <th>Endereço Remetente</th>
                    <th>Número Remetente</th>
                    <th>Bairro Remetente</th>
                    <th>Endereço Destinatário</th>
                    <th>Número Destinatário</th>
                    <th>Bairro Destinatário</th>
                    <th>Cidade</th>
                    <th>Dimensões</th>
                    <th>Peso</th>
                    <th>Valor</th>
                </tr>
            </thead>


            <?php
            include "../outros/conexao.inc";

            $resultado = $mysqli->query("SELECT * FROM solicitacaodaempresa");
            $linhas = $resultado->num_rows;
            if ($linhas == 0) {
                echo "Lista vazia <br><br>";
            } else {
                //repetição para rodar todas as linhas da tabela (tendo como base a quantidade encontrada e armazenada em $linhas)
                for ($i = 0; $i < $linhas; $i++) {
                    //cria um array chamado $reg que contém tudo que retornou no SELECT
                    $reg = $resultado->fetch_row();
                    //imprime os índices do array (cada coluna da tabela do banco é um índice ex: reg[0] é a primeira coluna por exemplo.)
                    echo "
                <tbody>
                    <tr>
                        <td>$reg[0]</td>
                        <td>$reg[1]</td>
                        <td>$reg[2]</td>
                        <td>$reg[3]</td>
                        <td>$reg[4]</td>
                        <td>$reg[5]</td>
                        <td>$reg[6]</td>
                        <td>$reg[7]</td>
                        <td>$reg[8]</td>
                        <td>$reg[9]</td>
                    </tr>
                </tbody>";
                }
            }
            ?>

        </table>
    </main>

    <?php
    include "../outros/rodape.inc";
    ?>
</body>

</html>