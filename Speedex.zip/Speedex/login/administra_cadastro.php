<html>

<body>
    <?php
    $operacao = $_POST["operacao"];
    include "../outros/conexao.inc";

    //-------------------------------- CADASTRO DE ENTREGADOR --------------------------------

    if ($operacao == "incluir_entregador") {

        //puxa o valor dos inputs da página (inclui)
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
        $confirmarSenha = $_POST["confirmarSenha"];

        $data_nascimento = $_POST["data_nascimento"];
        $sexo = $_POST["sexo"];
        $Cpf = $_POST["cpf"];
        $Celular = $_POST["celular"];
        $bairro = $_POST["bairro"];
        $rua = $_POST["rua"];
        $numero_residencia = $_POST["numero_residencia"];

        $PlacaVeiculo = $_POST["placa"];
        $modeloVeiculo = $_POST["modelo"];
        $cor = $_POST["cor"];

        //testa se a conexão deu certo
        if ($mysqli->connect_error) {
            //se der falha na conexão, exibe o possivel erro
            die("Falha na conexão: " . $mysqli->connect_error);
        }

        if ($senha != $confirmarSenha) {
            // Senhas são iguais, você pode continuar o processamento do formulário
            echo "<script>alert('as senhas não coincidem. Tente novamente.')</script>";
            echo "<meta http-equiv='refresh' content='0;url=cadastro_entregador.php'>";
        } else {

            //define a string SQL a ser utilizada, usando as variáveis que resgataram os valores dos inputs
            $sql = "INSERT INTO entregador VALUES ";
            $sql .= "('$nome', '$email', '$senha', '$data_nascimento', '$sexo', '$Cpf', '$Celular', '$bairro', '$rua', $numero_residencia, '$PlacaVeiculo','$modeloVeiculo', '$cor')";

            //testa se não houve problemas
            if ($mysqli->query($sql) === TRUE) {
                //imprime que o registro ocorreu corretamente
                echo "<script> alert ('Cadastro feito com sucesso! Bem vindo :)') </script>";
                echo "<meta http-equiv='refresh' content='0;url=../entregador/homeEntregador.php'>";
            } else {
                echo "Erro na inserção: " . $mysqli->error;
            }
        }
    }




    //-------------------------------- CADASTRO DE EMPRESA --------------------------------

    if ($operacao == "incluir_empresa") {

        //puxa o valor dos inputs da página (inlcui)
        $nome_empresa = $_POST["nome_empresa"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
        $cpf = $_POST["cpf_empresa"];
        $natureza = $_POST["natureza"];
        $orgaoPublico = $_POST["orgaoPublico"];
        $poder_subteto = $_POST["poder_subteto"];
        $ente_federativo = $_POST["ente_federativo"];
        $regime_previdencia = $_POST["regime_previdencia"];
        $cnpj = $_POST["cnpj"];
        $valor_subteto = $_POST["valor_subteto"];
        $celular = $_POST["celular"];
        $cep = $_POST["cep"];
        $bairro = $_POST["bairro"];
        $rua = $_POST["rua"];
        $numero = $_POST["numero"];

        //testa se a conexão deu certo
        if ($mysqli->connect_error) {
            //se der falha na conexão, exibe o possivel erro
            die("Falha na conexão: " . $mysqli->connect_error);
        }

        if ($senha != $confirmarSenha) {
            // Senhas são iguais, você pode continuar o processamento do formulário
            echo "<script>alert('as senhas não coincidem. Tente novamente.')</script>";
            echo "<meta http-equiv='refresh' content='0;url=cadastro_empresa.php'>";
        } else {

            //define a string SQL a ser utilizada, usando as variáveis que resgataram os valores dos inputs
            $sql = "INSERT INTO remetente VALUES ";
            $sql .= "('$nome_empresa', '$email', '$senha', '$cpf', '$natureza', '$orgaoPublico', '$poder_subteto', '$ente_federativo', '$regime_previdencia', '$cnpj', $valor_subteto, '$celular', '$cep', '$bairro', '$rua', $numero)";

            //testa se não houve problemas
            if ($mysqli->query($sql) === TRUE) {
                echo "<script> alert ('Cadastro feito com sucesso! Bem vindo :)') </script>";
                echo "<meta http-equiv='refresh' content='0;url=../solicitar_entrega.php'>";
            } else {
                echo "Erro na inserção: " . $mysqli->error;
            }
        }
    }




    //--------------------------------- CADASTRO PESSOAL ----------------------------------

    if ($operacao == "incluir_pessoal") {

        //puxa o valor dos inputs da página (inclui)
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
        $confirmarSenha = $_POST["confirmarSenha"];
        $data_nascimento = $_POST["data_nascimento"];
        $sexo = $_POST["sexo"];
        $cpf = $_POST["cpf"];
        $celular = $_POST["celular"];
        $cep = $_POST["cep"];
        $bairro = $_POST["bairro"];
        $rua = $_POST["rua"];
        $numero_residencia = $_POST["numero_residencia"];

        if ($senha != $confirmarSenha) {
            // Senhas são iguais, você pode continuar o processamento do formulário
            echo "<script>alert('as senhas não coincidem. Tente novamente.')</script>";
            echo "<meta http-equiv='refresh' content='0;url=cadastro_pessoal.php'>";
        } else {

            //define a string SQL a ser utilizada, usando as variáveis que resgataram os valores dos inputs
            $sql = "INSERT INTO destinatario VALUES ";
            $sql .= "('$nome', '$email', '$senha', '$data_nascimento', '$sexo', '$cpf', '$celular', '$cep', '$bairro', '$rua', $numero_residencia)";


            //testa se não houve problemas
            if ($mysqli->query($sql) === TRUE) {
                //imprime que o registro ocorreu corretamente
                echo "<script> alert ('Cadastro feito com sucesso! Bem vindo :)') </script>";
                echo "<meta http-equiv='refresh' content='0;url=../index.php'>";
            } else {
                echo "Erro na inserção: " . $mysqli->error;
            }
        }
    }
    ?>
</body>

</html>