<?php

$email = $_POST["email"];
$senha = $_POST["senha"];
$operacao = $_POST["operacao"];

include "../outros/conexao.inc";

//-------------------------------- PROCESSA LOGIN DE ENTREGADOR --------------------------------

if ($operacao == "login_entregador") {

    $resultado = $mysqli->query("SELECT * FROM entregador WHERE email ='$email'");
    $linhas = $resultado->num_rows;

    if ($linhas == 0) { // testa se a consulta retornou algum registro
        echo "<script> alert ('O e-mail inserido não consta no banco de dados. Tente novamente') </script>";
        echo "<meta http-equiv='refresh' content='0;url=../index.php'>";
    } else {
        $registro = $resultado->fetch_array();

        if ($senha != $registro["senha"]) { // confere senha
            echo " <script> alert ('Senha incorreta. Tente novamente.') </script>";
            echo "<meta http-equiv='refresh' content='0;url=../index.php'>";
        } else { // usuário e senha corretos. Vamos criar os cookies
            session_start();
            $_SESSION['nome_usuario'] = $nome;
            $_SESSION['senha_usuario'] = $nome;

            // direciona para a página inicial dos usuários cadastrados
            header("Location: ../entregador/homeEntregador.php");
        }
    }
}


//-------------------------------- PROCESSA LOGIN DE EMPRESA --------------------------------

if ($operacao == "login_empresa") {

    $resultado = $mysqli->query("SELECT * FROM remetente WHERE email ='$email'");
    $linhas = $resultado->num_rows;

    if ($linhas == 0) { // testa se a consulta retornou algum registro
        echo "<script> alert ('O e-mail inserido não consta no banco de dados. Tente novamente') </script>";
        echo "<meta http-equiv='refresh' content='0;url=../index.php'>";
    } else {
        $registro = $resultado->fetch_array();

        if ($senha != $registro["senha"]) { // confere senha
            echo " <script> alert ('Senha incorreta. Tente novamente.') </script>";
            echo "<meta http-equiv='refresh' content='0;url=../index.php'>";
        } else { // usuário e senha corretos. Vamos criar os cookies
            session_start();
            $_SESSION['nome_usuario'] = $nome;
            $_SESSION['senha_usuario'] = $nome;

            // direciona para a página inicial dos usuários cadastrados
            header("Location: ../empresa/solicitar_entrega.php");
        }
    }
}


//-------------------------------- PROCESSA LOGIN PESSOAL --------------------------------

if ($operacao == "login_pessoal") {

    $resultado = $mysqli->query("SELECT * FROM destinatario WHERE email ='$email'");
    $linhas = $resultado->num_rows;

    if ($linhas == 0) { // testa se a consulta retornou algum registro
        echo "<script> alert ('O e-mail inserido não consta no banco de dados. Tente novamente') </script>";
        echo "<meta http-equiv='refresh' content='0;url=../index.php'>";
    } else {
        $registro = $resultado->fetch_array();

        if ($senha != $registro["senha"]) { // confere senha
            echo " <script> alert ('Senha incorreta. Tente novamente.') </script>";
            echo "<meta http-equiv='refresh' content='0;url=../index.php'>";
        } else { // usuário e senha corretos. Vamos criar os cookies
            session_start();
            $_SESSION['nome_usuario'] = $nome;
            $_SESSION['senha_usuario'] = $nome;

            // direciona para a página inicial dos usuários cadastrados
            header("Location: ../index.php");
        }
    }
}


$mysqli->close();
