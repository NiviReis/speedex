<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style_login.css">
    <title>Cadastro - Pessoal</title>
</head>

<body>
    <?php
    include "../outros/conexao.inc";
    ?>
    <header>
        <img src="../outros/speedex.png" class="logo">
    </header><br>

    <div class="tabs">
        <div class="tab" onclick="openTab('dadosConta')">Conta</div>
        <div class="tab" onclick="openTab('dadosPessoais')">Pessoal</div>
    </div>

    <form class="form" action="administra_cadastro.php" method="post" id="schedule-form">
        <!-- Dados da Conta -->
        <div id="dadosConta" class="tab-content" style="display: block;">
            <input type="hidden" name="operacao" value="incluir_pessoal">

            <div class="input-container">
                <input type="text" placeholder="Nome" name="nome" required>
            </div>

            <div class="input-container">
                <input type="email" placeholder="E-mail" name="email" required>
            </div>

            <div class="input-container">
                <input type="password" placeholder="Senha" name="senha" required>
            </div>

            <div class="input-container">
                <input type="password" placeholder="Confirmar Senha" name="confirmarSenha" required>
            </div>
        </div>

        <!------------------------------------------------------------------------------------------------->

        <!-- Restante do formulário de dados pessoais -->
        <div id="dadosPessoais" class="tab-content">
            <div class="input-input_data">
                <label for="nascimento">Data de Nascimento:</label>
                <input type="date" name="data_nascimento" required class="input_data">
            </div>

            <div>
                <label for="sexo">Sexo:</label>
                <select class="select_sexo" name="sexo">
                    <p>Sexo:</p>
                    <option name="sexo" value="feminino">Feminino</option>
                    <option name="sexo" value="masculino">Masculino</option>
                    <option name="sexo" value="outro">Outro</option>
                </select>
            </div>

            <div class="input-container">
                <input type="text" id="cpf" placeholder="CPF" name="cpf" required oninput="formatarCPF(this)">
            </div>

            <div class="input-container">
                <input type="text" placeholder="Celular" name="celular" required oninput="formatarPhone(this)">
            </div>

            <div class="input-container">
                <input type="text" placeholder="CEP" name="cep" required>
            </div>

            <div class="input-container">
                <input type="text" placeholder="Bairro" name="bairro" required>
            </div>

            <div class="input-container">
                <input type="text" placeholder="Rua" name="rua" required>
            </div>

            <div class="input-container">
                <input type="number" placeholder="Nº de Residência" name="numero_residencia" required>
            </div>

            <button type="submit" class="submit">
                Confirmar inscrição
            </button>

            <p class="signup-link">
                Já tem uma conta?
                <a href="../index.php">Login</a>
            </p>
        </div>
        </section>
    </form>

    <script>
        function openTab(tabName) {
            var i;
            var tabContent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabContent.length; i++) {
                tabContent[i].style.display = "none";
            }
            document.getElementById(tabName).style.display = "block";
        }
    </script>

</body>

</html>