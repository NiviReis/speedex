function formatarCPF(input) {
    // Remove todos os caracteres que não sejam dígitos
    let cpf = input.value.replace(/\D/g, '');

    // Verifica se o CPF tem mais de 11 dígitos
    if (cpf.length > 11) {
        cpf = cpf.substr(0, 11);
    }

    // Adiciona pontos e hífen ao CPF
    cpf = cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');

    // Atualiza o valor do input
    input.value = cpf;
}

function formatarCNPJ(input) {
    let cnpj = input.value.replace(/\D/g, '');

    cnpj = cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');

    input.value = cnpj;
}

function formatarCNPJENTE(input) {
    let cnpjEnte = input.value.replace(/\D/g, '');

    cnpjEnte = cnpjEnte.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');

    input.value = cnpjEnte;
}
