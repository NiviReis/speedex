<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style_login.css">
    <title>Cadastro - Empresa</title>
</head>

<body>

    <img src="../outros/speedex.png" class="logo"><br><br>

    <section>
        <div class="tabs">
            <div class="tab" onclick="openTab('dadosConta')">Conta</div>
            <div class="tab" onclick="openTab('dadosEmpresa')">Empresa</div>
            <div class="tab" onclick="openTab('contatoLocal')">Contato</div>
        </div>

        <form class="form" action="administra_cadastro.php" method="post" id="schedule-form">
            <input type="hidden" name="operacao" value="incluir_empresa">

            <div id="dadosConta" class="tab-content" style="display: block;">
                <!-- Dados da Conta -->
                <div class="input-container">
                    <input type="text" placeholder="Nome da Empresa" name="nome_empresa" required>
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Email" name="email" required>
                </div>

                <div class="input-container">
                    <input type="password" placeholder="Senha" name="senha" required>
                </div>

                <div class="input-container">
                    <input type="password" placeholder="Confirme sua Senha" name="confirmarSenha" required>
                </div>
            </div>

            <div id="dadosEmpresa" class="tab-content" style="display: none;">
                <!-- Tipo de Ente -->
                <div>
                    <div class="input-container">
                        <input type="text" placeholder="CPF" name="cpf_empresa" required>
                    </div>

                    <div class="input-container">
                        <input type="text" placeholder="Natureza Jurídica" name="natureza" required>
                    </div>

                    <div class="input-container">
                        <input placeholder="Órgão Público" type="text" name="orgaoPublico" required>
                    </div>

                    <select class="select" name="poder_subteto">
                        <option name="poder_subteto" value="Executivo">Poder Subteto</option>
                        <option name="poder_subteto" value="Executivo">Executivo</option>
                        <option name="poder_subteto" value="Legislativo">Legislativo</option>
                        <option name="poder_subteto" value="Judiciario">Judiciario</option>
                        <option name="poder_subteto" value="Todos">Todos</option>
                    </select>
                </div><br>

                <div>
                    <select class="select" name="ente_federativo">
                        <option name="ente_federativo" value="">Ente Federativo</option>
                        <option name="ente_federativo" value="Sim">Sim</option>
                        <option name="ente_federativo" value="Nao">Não</option>
                    </select>
                </div><br>

                <div>
                    <select class="select" name="regime_previdencia">
                        <option name="" value="Sim">Regime Próprio de Providência</option>
                        <option name="regime_previdencia" value="Sim">Sim</option>
                        <option name="regime_previdencia" value="Nao">Não</option>
                    </select>
                </div><br>

                <div class="input-container">
                    <input type="text" placeholder="CNPJ/CEI" name="cnpj" id="cnpj" required oninput="formatarCNPJENTE(this)" maxlength="18">
                </div>

                <div class="input-container">
                    <input type="number" placeholder="Valor Subteto" name="valor_subteto" required>
                </div><br>
            </div>

            <div id="contatoLocal" class="tab-content" style="display: none;">
                <!-- Contato e Localização -->
                <div class="input-container">
                    <input placeholder="Celular" type="text" name="celular" required>
                </div>

                <div class="input-container">
                    <input type="text" placeholder="CEP" name="cep" required>
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Bairro" name="bairro" required>
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Rua" name="rua" required>
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Numero Residencial" name="numero" required>
                </div>

                <input class="submit" type="submit" value="Cadastrar">

                <p class="signup-link">
                    Já tem uma conta?
                    <a href="../index.php">Login</a>
                </p>
            </div>

        </form>
    </section>
    <script>
        function openTab(tabName) {
            var i;
            var tabContent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabContent.length; i++) {
                tabContent[i].style.display = "none";
            }
            document.getElementById(tabName).style.display = "block";
        }
    </script>

    <script src="cadastro.js"></script>
</body>

</html>