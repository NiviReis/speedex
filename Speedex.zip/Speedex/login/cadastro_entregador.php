<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style_login.css">
    <title>Cadastro - Entregador</title>

</head>

<body>
    <?php
    include "../outros/conexao.inc";
    ?>
    <section class="cabecalho">
        <header>
            <img src="../outros/speedex.png" class="logo">
        </header>
        <br><br>

        <section>
            <div class="tabs">
                <div class="tab" onclick="openTab('dadosConta')">Conta</div>
                <div class="tab" onclick="openTab('dadosPessoais')">Pessoal</div>
                <div class="tab" onclick="openTab('dadosVeiculo')">Veículo</div>
            </div>
        </section>

        <form method="post" id="schedule-form" class="form" action="administra_cadastro.php">

            <!-- Dados da Conta -->
            <div id="dadosConta" class="tab-content" style="display: block;">
                <input type="hidden" name="operacao" value="incluir_entregador">

                <div class="input-container">
                    <input type="text" placeholder="Nome" name="nome" required>
                </div>

                <div class="input-container">
                    <input type="email" placeholder="E-mail" name="email" required>
                </div>

                <div class="input-container">
                    <input type="password" placeholder="Senha" name="senha" required>
                </div>

                <div class="input-container">
                    <input type="password" placeholder="Confirmar Senha" name="confirmarSenha" required>
                </div>
            </div>

            <!------------------------------------------------------------------------------------------------->

            <!-- Restante do formulário de dados pessoais -->
            <div id="dadosPessoais" class="tab-content">
                <div class="input-input_data">
                    <label for="nascimento">Data de Nascimento:</label>
                    <input type="date" name="data_nascimento" required class="input_data">
                </div>

                <div>
                    <label for="sexo">Sexo:</label>
                    <select class="select_sexo" name="sexo">
                        <p>Sexo:</p>
                        <option name="sexo" value="feminino">Feminino</option>
                        <option name="sexo" value="masculino">Masculino</option>
                        <option name="sexo" value="outro">Outro</option>
                    </select>
                </div>

                <div class="input-container">
                    <input type="text" id="cpf" placeholder="CPF" name="cpf" required oninput="formatarCPF(this)">
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Celular" name="celular" required oninput="formatarPhone(this)">
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Bairro" name="bairro" required>
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Rua" name="rua" required>
                </div>

                <div class="input-container">
                    <input type="number" placeholder="Nº de Residência" name="numero_residencia" required>
                </div>
            </div>

            <!------------------------------------------------------------------------------------------------->

            <!-- Dados do Veículo -->
            <div id="dadosVeiculo" class="tab-content">
                <div class="input-container">
                    <input type="text" placeholder="Placa" name="placa" required maxlength="7">
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Modelo" name="modelo" required>
                </div>

                <div class="input-container">
                    <input type="text" placeholder="Cor" name="cor" required>
                </div>

                <button type="submit" class="submit">
                    Confirmar inscrição
                </button>

                <p class="signup-link">
                    Já tem uma conta?
                    <a href="../index.php">Login</a>
                </p>
            </div>
        </form>
    </section>

    <script>
        function openTab(tabName) {
            var i;
            var tabContent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabContent.length; i++) {
                tabContent[i].style.display = "none";
            }
            document.getElementById(tabName).style.display = "block";
        }
    </script>
</body>

</html>